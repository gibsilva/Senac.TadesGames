/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Senac.TadesGames.Service;


import Senac.TadesGames.DAO.ProdutoDAO;
import Senac.TadesGames.Helpers.Notificacao;
import Senac.TadesGames.Models.ProdutoModel;
import java.io.IOException;
import java.util.List;
/**
 *
 * @author caio_
 */
public class ProdutoService {
    
    private final ProdutoDAO produtoDao;
        private final Notificacao notificacao;

    
    public ProdutoService() {
        this.produtoDao = new ProdutoDAO();
            this.notificacao = new Notificacao();
    }
                public ProdutoModel obterPorId (int id){
        return produtoDao.obterPorId(id);
    }
    
    public List<ProdutoModel> obterListaProdutos(){
        return produtoDao.obterTodas();
    }
    public List<Notificacao> obterPorId(ProdutoModel id) throws Exception {
    
        try {
            produtoDao.inserir(id);{
             return this.notificacao.listaNotificacoes();
        }
        } catch (Exception e) {
            throw new Exception(e.getMessage());
        }
    }
        public void limparNotificacoes() {
        this.notificacao.limparLista();
    }
        
        
       //Insere um Produto na fonte de dados 
    public void inserir(ProdutoModel produto) throws IOException, Exception{

        try {
            produtoDao.inserir(produto);
        } catch (Exception e) {
            throw new Exception(e.getMessage());
        }
    }
    
        
        
}
